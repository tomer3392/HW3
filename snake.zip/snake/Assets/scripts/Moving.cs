﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Moving : MonoBehaviour
{
    //המשתמש באצם נועד לסמל עם הנכס יכול להמשיך לזוז או נגע בקיר
    bool move = true;
    
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {   //מסמל את המחש player 
        Vector2 player = new Vector2(transform.position.x, transform.position.y);
        //השורה מתחת עומרת שהספרייט של הנחש צריך לעקוב אחר משתנה השחקן
        transform.position = player;
        //המשתנה בשורה מתחת נועד לשימוש הנחיית גבולות לנחש
        Vector2 playerp = new Vector2(transform.position.x, transform.position.y);
        playerp.x = Mathf.Clamp(-14, -27.9f, 27.8f);
        playerp.y = Mathf.Clamp(-14, -9.5f, 9.5f);
        //לולאה שמשמעותה שכל עוד תזוזה שווה עמת הנחש יזוז לפי פקודות השחקן
        while (move == true)
        {
            //משומה הנחש לא זז והמחשב נטקע בלולע אינסופית ואני לא יודע למה
            if(Input.GetKeyDown(KeyCode.LeftArrow)==true)
            {
                //תזוז שמאלה צאד אחד
                player = new Vector2(transform.position.x - 1,transform.position.y);
                transform.position = player;
                //אם השחקן עובר את הגבול השמאלי אז הלולאה עמרה להסתיים
                if(player.x == -27.9f)
                {
                    move = false;
                }
            }
        }
        //עם תזוז שווה לשקר אז הנחש עוצר והוא אמור להגיד סוף משחק
        if (move == false)
        {
            //אם הנחש היה עושה את מה שאמרתי הייתי משנה את התקסט שהמחש יההרס
            player = new Vector2(transform.position.x, transform.position.y);
            print("game over");
        }
    }
}
